﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Figura> figure = new List<Figura>();
            figure.Add(new Rettangolo(2,3));
            figure.Add(new Quadrato(5));
            figure.Add(new Cerchio(6));
            figure.Add(new Parallelepipedo(3, 2, 3));
            figure.ForEach(f => Console.WriteLine(f.ToString()));
            Console.ReadLine();
        }
    }
}
