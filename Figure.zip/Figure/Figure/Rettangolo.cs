﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Rettangolo : Figura
    {
        
        public Rettangolo(double altezza, double Base) : base(altezza, Base, 4)
        {
            
        }
        public double Altezza { get => _altezza; set => _altezza = value; }
        public double Base { get => _base; set => _base = value; }

        public double CalcolaArea()
        {
            _area = _altezza * _base;
            return _area;
        }
        public double CalcoloPerimetro()
        {
            _perimetro = (_altezza * 2) + (_base * 2);
            return _perimetro;
        }
        public override string ToString()
        {
            return String.Format($"RETTANGOLO = AREA:{CalcolaArea()}, PERIMETRO: {CalcoloPerimetro()}, BASE:{_base}, ALTEZZA: {_altezza}");
        }

    }
}
