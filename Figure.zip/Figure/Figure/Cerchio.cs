﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Cerchio : Figura
    {
        public Cerchio(double raggio):base(raggio, 0)
        {

        }
        public double CalcolaPerimetro()
        {
            _perimetro = (_base * 2) * 3.14;
            return _perimetro;
        }
        public double CalcolaArea()
        {
            _area = (_base * _base) * 3.14;
            return _area;
        }
        public override string ToString()
        {
            return String.Format($"CERCHIO = AREA:{CalcolaArea()}, PERIMETRO: {CalcolaPerimetro()}, RAGGIO: {_base}");
        }

    }
}
