﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Quadrato: Figura
    {
        public Quadrato(double lato): base(lato, 4)
        {

        }
        public double CalcolaArea()
        {
            _area = _base * _base;
            return _area;
        }
        public double CalcoloPerimetro()
        {
            _perimetro = _base * 4;
            return _perimetro;
        }
        public override string ToString()
        {
            return String.Format($"QUADRATO = AREA:{CalcolaArea()}, PERIMETRO: {CalcoloPerimetro()}, LATO: {_base}");
        }
    }
}
