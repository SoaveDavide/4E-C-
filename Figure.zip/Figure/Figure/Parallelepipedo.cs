﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Parallelepipedo: Rettangolo
    {
        double _profondita, _volume;
        public Parallelepipedo(double profondita, double altezza, double Base): base(altezza, Base)
        {
            _profondita = profondita;
        }
        public double Profondita { get => _profondita; set => _profondita = value; }

        public double CalcolaVolume()
        {
            _volume = _profondita * _altezza * _base;
            return _volume;
        }
        public override string ToString()
        {
            return String.Format($"PARALLELEPIPEDO = VOLUME: {CalcolaVolume()}, BASE:{_base}, ALTEZZA: {_altezza}, PROFONDITA': {_profondita}");
        }
    }
}
