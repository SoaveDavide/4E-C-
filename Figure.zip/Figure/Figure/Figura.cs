﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure
{
    internal class Figura
    {
        protected double _base, _altezza;
        protected int _nlati;
        protected double _perimetro;
        protected double _area;

        public Figura(double Base, int nlati)//costruttore per altre figure
        {
            _base = Base;
            _nlati = nlati;
        }
        public Figura(double lato1, double lato2, int nlati)//costruttore per rettangolo e parallelepipedo
        {
            _base = lato1;
            _altezza = lato2;
            _nlati = nlati;
        }
        
    }
}
