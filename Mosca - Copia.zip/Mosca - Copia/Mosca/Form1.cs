﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mosca
{
    public partial class Form1 : Form
    {
        Point xy;
        Random posizione = new Random();
        string path = Environment.CurrentDirectory + "\\mosca_immagini"; //serve a recuperare il contenuto della cartella
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Mosca.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            xy.X = posizione.Next(0, (area.ClientSize.Width - Bug.Width) + 1);
            xy.Y = posizione.Next(0, (area.ClientSize.Height - Bug.Height) + 1);
            Bug.Location = xy;
        }

        private void Bug_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            Bug.Image = Image.FromFile(path + "\\moscaX.gif");//caricare la nuova immagine
            MessageBox.Show("Colpito", "MSG", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            Bug.Image = Image.FromFile(path + "\\mosca.gif");
            timer1.Enabled = true;
        }
        private void Mosca_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Evento generato");

        }
    }
}
